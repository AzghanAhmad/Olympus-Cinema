'use client';

import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { useRouter, useParams } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PublicLayout } from '@/components/layout/PublicLayout';
import { CinemaSeatMap } from '@/components/booking/CinemaSeatMap';
import { SeatHoldTimer } from '@/components/booking/SeatHoldTimer';
import { useBookingStore } from '@/store/useBookingStore';
import { useSiteSettingsStore } from '@/store/useSiteSettingsStore';
import { useAuthStore } from '@/store/useAuthStore';
import { screeningService } from '@/services/screeningService';
import { movieService } from '@/services/movieService';
import { bookingService } from '@/services/bookingService';
import { computeAisleAfterByRow } from '@/lib/seatLayout';
import { Seat, Screening } from '@/types/screening';
import { Movie } from '@/types/movie';
import { formatCurrency, formatDate } from '@/lib/utils';
import { toast } from '@/store/useToastStore';
import { ArrowRight, ArrowLeft, ShieldCheck } from 'lucide-react';

const guestSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  email: z.string().email('Valid email address is required'),
  phone: z.string().min(7, 'Phone number is required'),
});

type GuestFormData = z.infer<typeof guestSchema>;

async function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<T>((resolve) => {
        timer = setTimeout(() => resolve(fallback), ms);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export default function BookingPage() {
  const router = useRouter();
  const params = useParams();
  const screeningId = params.screeningId as string;

  const [screening, setScreening] = useState<Screening | null>(null);
  const [movie, setMovie] = useState<Movie | null>(null);
  const [seats, setSeats] = useState<Seat[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [emailOtp, setEmailOtp] = useState('');
  const [phoneOtp, setPhoneOtp] = useState('');

  const currentUser = useAuthStore((s) => s.user);
  const isAdminUser = useAuthStore((s) => s.isAdmin());
  const maxTickets = useSiteSettingsStore((s) => s.maxTicketsPerPerson);
  const cinemaName = useSiteSettingsStore((s) => s.cinemaName);

  const {
    selectedSeats,
    customer,
    step,
    setStep,
    setCustomer,
    setScreeningAndMovie,
    getTotalPrice,
    emailVerified,
    phoneVerified,
    emailCodeSent,
    phoneCodeSent,
    sendEmailCode,
    sendPhoneCode,
    verifyEmailCode,
    verifyPhoneCode,
    setEmailVerified,
    otpSending,
  } = useBookingStore();

  const {
    register,
    handleSubmit,
    getValues,
    setValue,
    reset,
    formState: { errors },
  } = useForm<GuestFormData>({
    resolver: zodResolver(guestSchema),
    defaultValues: {
      fullName: customer.fullName || currentUser?.name || '',
      email: customer.email || currentUser?.email || '',
      phone: customer.phone || currentUser?.phone || '',
    },
  });

  // Autofill form if user signs in or user profile hydrates, auto-verify if admin
  useEffect(() => {
    if (currentUser) {
      const currentValues = getValues();
      const newFullName = currentValues.fullName || currentUser.name || '';
      const newEmail = currentValues.email || currentUser.email || '';
      const newPhone = currentValues.phone || currentUser.phone || '';

      if (newFullName !== currentValues.fullName) setValue('fullName', newFullName);
      if (newEmail !== currentValues.email) setValue('email', newEmail);
      if (newPhone !== currentValues.phone) setValue('phone', newPhone);

      // Pre-populate customer in booking store as well so review matches
      setCustomer({
        fullName: newFullName,
        email: newEmail,
        phone: newPhone,
      });

      if (isAdminUser) {
        setEmailVerified(true);
      }
    }
  }, [currentUser, isAdminUser, setValue, getValues, setCustomer, setEmailVerified]);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      setLoadError(null);
      try {
        const scr = await screeningService.getScreeningById(screeningId);
        if (!scr) {
          setLoadError('This showtime could not be found. It may have been removed.');
          return;
        }
        setScreening(scr);

        // Load seats and movie in parallel (guest-friendly; no auth required)
        const [seatList, mov] = await Promise.all([
          withTimeout(screeningService.getScreeningSeats(scr.id), 12000, []),
          withTimeout(movieService.getMovieById(scr.movieId), 12000, null),
        ]);
        setSeats(seatList);

        const resolvedMovie =
          mov ??
          ({
            id: scr.movieId,
            title: scr.movieTitle || 'Majnoon',
            slug: 'majnoon',
            tagline: '',
            synopsis: '',
            genre: [],
            durationMinutes: 120,
            releaseDate: scr.date,
            language: 'Dhivehi',
            ageRating: 'PG-13',
            rating: 0,
            posterUrl: scr.moviePoster || '/images/majnoon-poster.jpg',
            backdropUrl: '/images/majnoon-backdrop.jpg',
            trailerUrl: '',
            status: 'NOW_SHOWING',
            cast: [],
            crew: [],
            gallery: [],
          } satisfies Movie);

        setMovie(resolvedMovie);
        setScreeningAndMovie(scr, resolvedMovie);

        if (!seatList.length) {
          console.warn('Seat map returned 0 seats for screening', scr.id);
        }
      } catch (err) {
        setLoadError(
          err instanceof Error
            ? err.message
            : 'Could not load the seat map. Check your connection and try again.',
        );
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [screeningId, setScreeningAndMovie]);

  const aisleMap = computeAisleAfterByRow(seats);

  if (loading) {
    return (
      <PublicLayout>
        <div className="max-w-7xl mx-auto px-4 py-24 text-center space-y-4">
          <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-muted-foreground text-sm font-semibold">Loading seat map...</p>
        </div>
      </PublicLayout>
    );
  }

  if (loadError || !screening || !movie) {
    return (
      <PublicLayout>
        <div className="max-w-lg mx-auto px-4 py-24 text-center space-y-4">
          <p className="text-sm text-muted-foreground font-semibold">
            {loadError || 'Unable to open this reservation.'}
          </p>
          <a
            href="/screenings"
            className="inline-flex px-5 py-2.5 bg-primary text-primary-foreground text-xs font-bold rounded-xl"
          >
            Back to showtimes
          </a>
        </div>
      </PublicLayout>
    );
  }

  const handleGuestSubmit = (data: GuestFormData) => {
    setCustomer(data);
    if (!isAdminUser && !emailVerified) {
      toast.warning('Verify email', 'Please verify your email address with the code before continuing.');
      return;
    }
    setStep(3);
  };

  const handleConfirmBooking = async () => {
    if (!isAdminUser && !emailVerified) {
      toast.error('Verification required', 'Please verify your email before reserving.');
      setStep(2);
      return;
    }

    try {
      const newBooking = await bookingService.createBooking({
        screeningId: screening.id,
        movieId: movie.id,
        movieTitle: movie.title,
        moviePoster: movie.posterUrl,
        hallName: cinemaName || screening.hallName,
        screenType: screening.screenType,
        date: screening.date,
        startTime: screening.startTime,
        seats: selectedSeats,
        customer,
        totalPrice: getTotalPrice(),
      });
      router.push(`/booking/confirmation?bookingId=${newBooking.id}`);
    } catch (err) {
      toast.error(
        'Reservation failed',
        err instanceof Error ? err.message : 'Could not submit booking. Please try again.',
      );
    }
  };

  return (
    <PublicLayout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <div className="p-4 bg-card border border-border rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
          <div className="flex items-center space-x-2 text-xs font-bold">
            <span className={`px-3 py-1 rounded-full ${step >= 1 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
              1. Seats
            </span>
            <span>→</span>
            <span className={`px-3 py-1 rounded-full ${step >= 2 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
              {isAdminUser ? '2. Customer Details' : '2. Verify & Details'}
            </span>
            <span>→</span>
            <span className={`px-3 py-1 rounded-full ${step >= 3 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}>
              3. Reserve
            </span>
          </div>
          <SeatHoldTimer />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {step === 1 && (
              <div className="p-4 sm:p-6 bg-card border border-border rounded-3xl space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-border pb-4 gap-2">
                  <div>
                    <h2 className="text-xl font-extrabold">Select Your Seats</h2>
                    <p className="text-xs text-muted-foreground">
                      Maximum {maxTickets} tickets per person. {selectedSeats.length}/{maxTickets} selected.
                    </p>
                  </div>
                </div>

                {seats.length === 0 && (
                  <p className="text-sm text-amber-600 dark:text-amber-400 font-semibold text-center py-4">
                    No seats were returned for this showtime. Please refresh or choose another show.
                  </p>
                )}
                <CinemaSeatMap seats={seats} aisleAfterByRow={aisleMap} />

                <div className="flex flex-col sm:flex-row justify-end pt-4 border-t border-border">
                  <button
                    disabled={selectedSeats.length === 0}
                    onClick={() => setStep(2)}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 bg-primary text-primary-foreground font-bold text-sm rounded-xl shadow-lg shadow-primary/30 hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    <span>Continue ({selectedSeats.length} seats)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="p-4 sm:p-8 bg-card border border-border rounded-3xl space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-border pb-4 gap-2">
                  <div>
                    <h2 className="text-xl font-extrabold">
                      {isAdminUser ? 'Customer Details' : 'Guest Details & Verification'}
                    </h2>
                    <p className="text-xs text-muted-foreground">
                      {isAdminUser
                        ? 'Admin Direct Booking — Email verification and OTP are bypassed.'
                        : 'Verify email or phone with a code before your reservation is created.'}
                    </p>
                  </div>
                  <button
                    onClick={() => setStep(1)}
                    className="text-xs font-bold text-primary hover:underline flex items-center gap-1 self-start sm:self-auto"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" /> Back to Seats
                  </button>
                </div>

                <form onSubmit={handleSubmit(handleGuestSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold mb-1">Full Name</label>
                    <input
                      {...register('fullName')}
                      className="w-full py-2.5 px-3 bg-secondary text-foreground text-sm rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    {errors.fullName && <p className="text-xs text-primary mt-1">{errors.fullName.message}</p>}
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-semibold mb-1">Email Address</label>
                    {isAdminUser ? (
                      <div>
                        <input
                          {...register('email')}
                          type="email"
                          className="w-full py-2.5 px-3 bg-secondary text-foreground text-sm rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                        />
                        <p className="text-xs font-bold text-emerald-600 flex items-center gap-1 mt-1.5">
                          ✓ Verified (Admin Booking — OTP waived)
                        </p>
                      </div>
                    ) : (
                      <>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <input
                            {...register('email')}
                            type="email"
                            className="flex-1 py-2.5 px-3 bg-secondary text-foreground text-sm rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const email = getValues('email');
                              if (!email || !email.includes('@')) {
                                toast.warning('Enter email', 'Add a valid email first.');
                                return;
                              }
                              setCustomer({ ...getValues(), email });
                              void sendEmailCode(email);
                            }}
                            disabled={otpSending}
                            className="w-full sm:w-auto px-4 py-2.5 bg-secondary border border-border rounded-xl text-xs font-bold shrink-0 disabled:opacity-50"
                          >
                            Send code
                          </button>
                        </div>
                        {errors.email && <p className="text-xs text-primary mt-1">{errors.email.message}</p>}
                        {emailCodeSent && !emailVerified && (
                          <div className="space-y-2 pt-1">
                            <div className="flex flex-col sm:flex-row gap-2">
                              <input
                                value={emailOtp}
                                onChange={(e) => setEmailOtp(e.target.value)}
                                placeholder="Enter email code"
                                className="flex-1 py-2 px-3 bg-secondary text-foreground text-sm rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                              />
                              <button
                                type="button"
                                onClick={() => void verifyEmailCode(emailOtp)}
                                className="w-full sm:w-auto px-4 py-2 bg-primary text-primary-foreground rounded-xl text-xs font-bold shadow hover:bg-primary/90 transition-all shrink-0"
                              >
                                Verify email
                              </button>
                            </div>
                            <p className="text-[11px] text-muted-foreground">
                              Enter the 6-digit code sent to your email inbox.
                            </p>
                          </div>
                        )}
                        {emailVerified && (
                          <p className="text-xs font-bold text-emerald-600 flex items-center gap-1 mt-1">
                            ✓ Email verified successfully
                          </p>
                        )}
                      </>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-semibold mb-1">Phone Number</label>
                    <input
                      {...register('phone')}
                      placeholder="e.g. 7890000"
                      className="w-full py-2.5 px-3 bg-secondary text-foreground text-sm rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    {errors.phone && <p className="text-xs text-primary mt-1">{errors.phone.message}</p>}
                  </div>

                  {!isAdminUser && (
                    <p className="text-[11px] text-muted-foreground">
                      A 6-digit verification code will be sent to your email to verify your reservation.
                    </p>
                  )}

                  <div className="pt-4 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="w-full sm:w-auto px-5 py-3 bg-secondary text-secondary-foreground font-semibold rounded-xl text-xs text-center"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 sm:px-8 py-3.5 bg-primary text-primary-foreground font-bold text-sm rounded-xl shadow-lg shadow-primary/30 hover:bg-primary/90 transition-all"
                    >
                      <span>Review Reservation</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </form>
              </div>
            )}

            {step === 3 && (
              <div className="p-4 sm:p-8 bg-card border border-border rounded-3xl space-y-6">
                <div className="border-b border-border pb-4">
                  <h2 className="text-xl font-extrabold">Confirm Reservation</h2>
                  <p className="text-xs text-muted-foreground">
                    This creates an unconfirmed booking — not a ticket. You will get a ticket once it is paid.
                  </p>
                </div>

                <div className="space-y-4 text-sm">
                  <div className="p-4 bg-secondary/50 rounded-2xl space-y-2">
                    <h4 className="font-extrabold text-base text-primary">{movie.title}</h4>
                    <p className="text-xs text-muted-foreground">
                      {cinemaName} • {formatDate(screening.date)} at {screening.startTime}
                    </p>
                  </div>

                  <div className="p-4 bg-secondary/50 rounded-2xl space-y-2">
                    <h5 className="font-bold text-xs uppercase text-muted-foreground">Selected Seats</h5>
                    <div className="flex flex-wrap gap-2">
                      {selectedSeats.map((seat) => (
                        <span key={seat.id} className="px-3 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-lg">
                          {seat.label || `${seat.row}-${seat.number}`}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-4 bg-secondary/50 rounded-2xl space-y-1 text-xs">
                    <h5 className="font-bold text-muted-foreground uppercase">Customer</h5>
                    <p className="font-bold text-foreground">{customer.fullName}</p>
                    <p className="text-muted-foreground">{customer.email} • {customer.phone}</p>
                    <p className="text-emerald-600 font-semibold">
                      ✓ Verified via email ({customer.email})
                    </p>
                  </div>
                </div>

                <div className="pt-4 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  <button
                    onClick={() => setStep(2)}
                    className="w-full sm:w-auto px-5 py-3 bg-secondary text-secondary-foreground font-semibold rounded-xl text-xs text-center"
                  >
                    Edit Info
                  </button>

                  <button
                    onClick={handleConfirmBooking}
                    className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 sm:px-8 py-3.5 bg-primary text-primary-foreground font-black text-sm rounded-xl shadow-xl shadow-primary/40 hover:bg-primary/90 hover:scale-[1.02] transition-all"
                  >
                    <ShieldCheck className="w-5 h-5" />
                    Submit Reservation
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="p-6 bg-card border border-border rounded-3xl shadow-lg space-y-6 sticky top-24">
              <h3 className="font-extrabold text-lg border-b border-border pb-3">Reservation Summary</h3>

              <div className="flex gap-3">
                <div className="relative w-16 h-24 rounded-xl overflow-hidden bg-zinc-900 shrink-0 border border-border">
                  <Image src={movie.posterUrl} alt={movie.title} fill className="object-cover" />
                </div>
                <div className="space-y-1">
                  <h4 className="font-extrabold text-sm line-clamp-1">{movie.title}</h4>
                  <p className="text-xs text-muted-foreground">{cinemaName}</p>
                  <span className="inline-block text-[10px] font-bold px-2 py-0.5 rounded bg-primary/10 text-primary">
                    {formatDate(screening.date)} • {screening.startTime}
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-2 border-t border-border text-xs">
                <div className="flex justify-between font-semibold gap-2">
                  <span className="text-muted-foreground shrink-0">Seats ({selectedSeats.length}/{maxTickets})</span>
                  <span className="text-right">{selectedSeats.length > 0 ? selectedSeats.map((s) => s.label || `${s.row}-${s.number}`).join(', ') : 'None'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
}
